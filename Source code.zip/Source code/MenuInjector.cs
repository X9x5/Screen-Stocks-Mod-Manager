using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace ModManager
{
    /// <summary>
    /// Finds the game's pop-up menu (the one with Exit, Transactions, ...) at runtime and clones one of its
    /// buttons into it. Works off type names so it needs no compile-time reference to Assembly-CSharp.
    /// </summary>
    internal sealed class MenuInjector : MonoBehaviour
    {
        private const string CloneName = "ModManagerMenuButton";
        private const string OurCanvasName = "ModManagerCanvas";

        // Button groups that look like the menu but are not (skins list, achievements, trading UI...).
        private static readonly HashSet<string> ExcludedComponents = new HashSet<string>
        {
            "BGSkinButton", "BGSkinButtonManager", "AchievementCompendiumButtonUI",
            "AchievementCompendiumButtonManager", "AutoActionButtonUI", "StockButtonUI",
            "GeneratorButtonUI", "UpgradeButtonUI"
        };

        private static readonly HashSet<string> LocalizationComponents = new HashSet<string>
        {
            "LocChanger", "LocalizationAutoBinder"
        };

        private static readonly string[] ExitWords = { "exit", "quit" };
        private static readonly string[] MenuWords = { "exit", "quit", "transaction", "history" };

        private Type _customButtonType;
        private GameObject _clone;
        private float _nextScan;
        private float _startTime;
        private bool _loggedFirstScan;

        private void Start()
        {
            _startTime = Time.unscaledTime;
            _customButtonType = Type.GetType("CustomButton, Assembly-CSharp");
        }

        private void Update()
        {
            if (Time.unscaledTime < _nextScan) return;
            _nextScan = Time.unscaledTime + (_clone != null ? 2f : 0.5f);

            if (_clone != null) return; // still alive; Unity's == handles destroyed objects

            try
            {
                TryInject();
            }
            catch (Exception e)
            {
                ModManagerPlugin.Log.LogWarning("Menu injection failed: " + e);
            }

            var ui = ModManagerUI.Instance;
            if (ui == null) return;
            bool giveUp = Time.unscaledTime - _startTime > ModManagerPlugin.FallbackDelaySeconds.Value;
            ui.SetFloatingButton(_clone == null && giveUp && ModManagerPlugin.FloatingFallback.Value);
        }

        // ---------------------------------------------------------------- discovery

        private sealed class Group
        {
            public Transform Parent;
            public List<Transform> Items = new List<Transform>();
        }

        // Every button-like object in the loaded scenes (inactive ones included), grouped by container.
        private List<Group> FindGroups()
        {
            var comps = new List<Component>();
            if (_customButtonType != null)
                foreach (var o in Resources.FindObjectsOfTypeAll(_customButtonType))
                {
                    var c = o as Component;
                    if (c != null) comps.Add(c);
                }
            comps.AddRange(Resources.FindObjectsOfTypeAll<Button>().Cast<Component>());

            var map = new Dictionary<Transform, Group>();
            foreach (var c in comps)
            {
                var go = c.gameObject;
                if (!go.scene.IsValid() || !go.scene.isLoaded) continue; // skips prefab assets
                if ((go.hideFlags & HideFlags.HideAndDontSave) != 0) continue;
                if (go.transform.root.name == OurCanvasName) continue;

                var item = c.transform;
                for (int i = 0; i < 3 && item.parent != null && item.parent.childCount == 1; i++) item = item.parent;
                if (item.parent == null) continue;

                Group g;
                if (!map.TryGetValue(item.parent, out g)) map[item.parent] = g = new Group { Parent = item.parent };
                if (!g.Items.Contains(item)) g.Items.Add(item);
            }
            return map.Values.ToList();
        }

        private static string PathOf(Transform t)
        {
            var sb = new StringBuilder(t.name);
            for (var p = t.parent; p != null; p = p.parent) sb.Insert(0, p.name + "/");
            return sb.ToString();
        }

        private static string LabelOf(Transform t)
        {
            foreach (var tmp in t.GetComponentsInChildren<TMP_Text>(true))
            {
                string s = Regex.Replace(tmp.text ?? "", "<.*?>", "").Trim();
                if (s.Length > 0) return s;
            }
            foreach (var txt in t.GetComponentsInChildren<Text>(true))
            {
                string s = (txt.text ?? "").Trim();
                if (s.Length > 0) return s;
            }
            return "";
        }

        private static bool LabelHas(Transform t, string[] words)
        {
            string l = (LabelOf(t) + " " + t.name).ToLowerInvariant();
            return words.Any(w => l.Contains(w));
        }

        // True when the button's saved click handler calls the game's Quit / transaction history code.
        private bool HasKeyListener(Transform t, bool exitOnly)
        {
            var events = new List<UnityEventBase>();
            foreach (var b in t.GetComponentsInChildren<Button>(true)) events.Add(b.onClick);
            if (_customButtonType != null)
            {
                var field = _customButtonType.GetField("onClickedEvent");
                foreach (var comp in t.GetComponentsInChildren(_customButtonType, true))
                {
                    var ev = field != null ? field.GetValue(comp) as UnityEventBase : null;
                    if (ev != null) events.Add(ev);
                }
            }
            foreach (var ev in events)
            {
                for (int i = 0; i < ev.GetPersistentEventCount(); i++)
                {
                    string method = ev.GetPersistentMethodName(i) ?? "";
                    var target = ev.GetPersistentTarget(i);
                    string type = target != null ? target.GetType().Name : "";
                    if (method.IndexOf("Quit", StringComparison.OrdinalIgnoreCase) >= 0) return true;
                    if (!exitOnly && type.IndexOf("Transaction", StringComparison.OrdinalIgnoreCase) >= 0) return true;
                }
            }
            return false;
        }

        private bool IsExitItem(Transform t)
        {
            return LabelHas(t, ExitWords) || HasKeyListener(t, true);
        }

        private static bool IsExcluded(Group g)
        {
            foreach (var comp in g.Items[0].GetComponentsInChildren<Component>(true))
                if (comp != null && ExcludedComponents.Contains(comp.GetType().Name)) return true;
            foreach (var comp in g.Parent.GetComponents<Component>())
                if (comp != null && ExcludedComponents.Contains(comp.GetType().Name)) return true;
            return false;
        }

        private static bool IsOurs(Group g)
        {
            return g.Items.Any(t => t != null && t.name == CloneName);
        }

        // How strongly a group looks like the Exit/Transactions menu.
        private int MenuHits(Group g)
        {
            int hits = 0;
            foreach (var t in g.Items)
                if (LabelHas(t, MenuWords) || HasKeyListener(t, false)) hits++;
            return hits;
        }

        public void DumpCandidates()
        {
            var sb = new StringBuilder("[dump] Button groups in the loaded scenes:\n");
            foreach (var g in FindGroups().OrderByDescending(x => MenuHits(x)).ThenByDescending(x => x.Items.Count))
            {
                string labels = string.Join(" | ", g.Items.Take(10).Select(t =>
                {
                    string l = LabelOf(t);
                    return l.Length > 0 ? l : t.name;
                }).ToArray());
                sb.AppendLine($"  {PathOf(g.Parent)}  buttons={g.Items.Count} menuHits={MenuHits(g)} " +
                              $"active={g.Parent.gameObject.activeInHierarchy} excluded={IsExcluded(g)} ours={IsOurs(g)}\n" +
                              $"    labels: {labels}");
            }
            ModManagerPlugin.Log.LogInfo(sb.ToString());
        }

        // ---------------------------------------------------------------- injection

        // ---------------------------------------------------------------- replace an existing button (Tips)

        private Sprite _icon;

        // Finds the button to take over: label/name/click-handler type matching the keyword (default "tips").
        private Transform FindReplaceTarget(List<Group> groups, string keyword)
        {
            keyword = (keyword ?? "").Trim().ToLowerInvariant();
            if (keyword.Length == 0) return null;

            Transform best = null;
            int bestScore = 0;
            foreach (var g in groups)
                foreach (var t in g.Items)
                {
                    if (t == null || t.name == CloneName) continue;
                    int score = 0;
                    string label = LabelOf(t).ToLowerInvariant();
                    if (label == keyword) score = 3;
                    else if (t.name.ToLowerInvariant().Contains(keyword)) score = 2;
                    else if (ListenerTypeHas(t, keyword)) score = 1;
                    if (score > bestScore) { bestScore = score; best = t; }
                }
            return best ?? FindByText(keyword);
        }

        // Fallback when the button is not a Button/CustomButton: find the text, climb to whatever is clickable.
        private Transform FindByText(string keyword)
        {
            foreach (var tmp in Resources.FindObjectsOfTypeAll<TMP_Text>())
            {
                var go = tmp.gameObject;
                if (!go.scene.IsValid() || !go.scene.isLoaded) continue;
                if (go.transform.root.name == OurCanvasName) continue;
                string label = Regex.Replace(tmp.text ?? "", "<.*?>", "").Trim().ToLowerInvariant();
                if (label != keyword) continue;

                Transform clickable = null;
                bool insidePanel = false;
                var t = tmp.transform;
                for (int i = 0; i < 6 && t != null; i++, t = t.parent)
                {
                    foreach (var c in t.GetComponents<Component>())
                    {
                        if (c == null) continue;
                        string n = c.GetType().Name;
                        if (n == "TipsController") insidePanel = true;
                        if (clickable == null && (c is Selectable || c is EventTrigger || n == "CustomButton")) clickable = t;
                    }
                }
                if (clickable != null && !insidePanel) return clickable;
            }
            return null;
        }

        private bool ListenerTypeHas(Transform t, string keyword)
        {
            var events = new List<UnityEventBase>();
            foreach (var b in t.GetComponentsInChildren<Button>(true)) events.Add(b.onClick);
            if (_customButtonType != null)
            {
                var field = _customButtonType.GetField("onClickedEvent");
                foreach (var comp in t.GetComponentsInChildren(_customButtonType, true))
                {
                    var ev = field != null ? field.GetValue(comp) as UnityEventBase : null;
                    if (ev != null) events.Add(ev);
                }
            }
            foreach (var ev in events)
                for (int i = 0; i < ev.GetPersistentEventCount(); i++)
                {
                    var target = ev.GetPersistentTarget(i);
                    if (target != null && target.GetType().Name.ToLowerInvariant().Contains(keyword)) return true;
                }
            return false;
        }

        private static Image PickIcon(Transform item, List<TMP_Text> labels)
        {
            var all = item.GetComponentsInChildren<Image>(true).ToList();
            if (all.Count == 0) return null;
            if (all.Count == 1) return all[0];

            // Ignore images that belong to the hover label (its frame/background), and the button's own backdrop.
            var labelRoots = labels.Select(t => t.transform.parent != null && t.transform.parent != item
                                                ? t.transform.parent : t.transform).ToList();
            var imgs = all.Where(i => i.transform != item && !labelRoots.Any(r => i.transform.IsChildOf(r))).ToList();
            if (imgs.Count == 0) imgs = all.Where(i => i.transform != item).ToList();
            if (imgs.Count == 0) imgs = all;

            string[] iconWords = { "question", "tip", "help", "info", "icon", "glyph", "symbol" };
            string[] skipWords = { "glow", "bg", "background", "border", "select", "click", "frame", "shadow", "outline", "fill", "highlight" };

            var named = imgs.LastOrDefault(i => i.sprite != null &&
                            iconWords.Any(w => i.sprite.name.ToLowerInvariant().Contains(w)))
                        ?? imgs.LastOrDefault(i => iconWords.Any(w => i.gameObject.name.ToLowerInvariant().Contains(w)));
            if (named != null) return named;

            return imgs.LastOrDefault(i => i.sprite != null &&
                       !skipWords.Any(w => i.gameObject.name.ToLowerInvariant().Contains(w)))
                   ?? imgs[imgs.Count - 1];
        }

        // A smooth, single-colour "M" (anti-aliased), like the game's other flat one-colour icons.
        private Sprite GetIcon()
        {
            if (_icon != null) return _icon;
            const int N = 64;
            const float half = 5.2f; // half the stroke thickness, in texels
            var colour = new Color32(30, 74, 200, 255);

            // The letter as four strokes: left stem, right stem and the two diagonals meeting in the middle.
            var strokes = new[]
            {
                new[] { 15f, 12f, 15f, 52f },
                new[] { 49f, 12f, 49f, 52f },
                new[] { 15f, 52f, 32f, 26f },
                new[] { 49f, 52f, 32f, 26f }
            };

            var px = new Color32[N * N];
            for (int y = 0; y < N; y++)
                for (int x = 0; x < N; x++)
                {
                    float d = float.MaxValue;
                    foreach (var s in strokes)
                        d = Mathf.Min(d, SegmentDistance(x + 0.5f, y + 0.5f, s[0], s[1], s[2], s[3]));
                    float a = Mathf.Clamp01(half + 0.5f - d); // 1 inside, soft 1-texel edge
                    px[y * N + x] = new Color32(colour.r, colour.g, colour.b, (byte)Mathf.RoundToInt(a * 255f));
                }

            var tex = new Texture2D(N, N, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Bilinear;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.SetPixels32(px);
            tex.Apply();
            _icon = Sprite.Create(tex, new Rect(0, 0, N, N), new Vector2(0.5f, 0.5f), 100f);
            return _icon;
        }

        private static float SegmentDistance(float px, float py, float ax, float ay, float bx, float by)
        {
            float vx = bx - ax, vy = by - ay;
            float t = Mathf.Clamp01(((px - ax) * vx + (py - ay) * vy) / (vx * vx + vy * vy));
            float dx = px - (ax + t * vx), dy = py - (ay + t * vy);
            return Mathf.Sqrt(dx * dx + dy * dy);
        }

        private void AddBadge(Transform item)
        {
            var old = item.Find("ModManagerBadge");
            if (old != null) Destroy(old.gameObject);

            var badge = new GameObject("ModManagerBadge", typeof(RectTransform), typeof(Image), typeof(LayoutElement));
            badge.layer = item.gameObject.layer;
            var rt = (RectTransform)badge.transform;
            rt.SetParent(item, false);
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(3, 3);
            rt.offsetMax = new Vector2(-3, -3);
            rt.SetAsLastSibling();
            badge.GetComponent<LayoutElement>().ignoreLayout = true;
            var img = badge.GetComponent<Image>();
            img.sprite = GetIcon();
            img.raycastTarget = false;
            img.color = Color.white;
        }

        private bool TryReplaceButton(List<Group> groups)
        {
            var item = FindReplaceTarget(groups, ModManagerPlugin.ButtonToReplace.Value);
            if (item == null) return false;

            var sb = new StringBuilder();
            foreach (var i in item.GetComponentsInChildren<Image>(true))
                sb.AppendLine($"    image {PathOf(i.transform)} sprite={(i.sprite != null ? i.sprite.name : "none")}");

            var go = item.gameObject;
            string oldName = go.name;
            go.name = CloneName;

            // Labels are filled in by the game's localisation at runtime (and may be empty while hidden),
            // so remember which texts it drives before we remove it.
            var locTexts = new HashSet<TMP_Text>();
            foreach (var mb in go.GetComponentsInChildren<MonoBehaviour>(true))
                if (mb != null && LocalizationComponents.Contains(mb.GetType().Name))
                {
                    var driven = mb.GetComponent<TMP_Text>();
                    if (driven != null) locTexts.Add(driven);
                    DestroyImmediate(mb);
                }

            foreach (var b in go.GetComponentsInChildren<Button>(true))
            {
                DisablePersistent(b.onClick);
                b.onClick.AddListener(OpenManager);
            }
            if (_customButtonType != null)
            {
                var field = _customButtonType.GetField("onClickedEvent");
                foreach (var comp in go.GetComponentsInChildren(_customButtonType, true))
                {
                    var ev = field != null ? field.GetValue(comp) as UnityEventBase : null;
                    if (ev == null) continue;
                    DisablePersistent(ev);
                    var plain = ev as UnityEvent;
                    if (plain != null) plain.AddListener(OpenManager);
                }
            }

            // Only re-route clicks. Hover entries (PointerEnter/Exit) are what show the game's hover label,
            // so they must stay untouched.
            foreach (var et in go.GetComponentsInChildren<EventTrigger>(true))
                foreach (var entry in et.triggers)
                    if (entry.eventID == EventTriggerType.PointerClick || entry.eventID == EventTriggerType.Submit)
                    {
                        DisablePersistent(entry.callback);
                        entry.callback.AddListener(_ => OpenManager());
                    }

            // New hover label text, and the "M" badge in place of the old icon.
            string newLabel = ModManagerPlugin.ButtonLabel.Value;
            var labelTexts = new List<TMP_Text>();
            foreach (var t in go.GetComponentsInChildren<TMP_Text>(true))
                if (locTexts.Contains(t) || !string.IsNullOrWhiteSpace(Regex.Replace(t.text ?? "", "<.*?>", "")))
                {
                    t.text = newLabel;
                    labelTexts.Add(t);
                }
            foreach (var t in go.GetComponentsInChildren<Text>(true))
                if (!string.IsNullOrWhiteSpace(t.text)) t.text = newLabel;

            // Icon: swap the old icon image for our "M" badge (this worked before); if no icon image can be
            // identified, draw the badge on top of the button instead.
            Image icon = null;
            string forced = (ModManagerPlugin.IconImageName.Value ?? "").Trim();
            if (forced.Length > 0)
                icon = go.GetComponentsInChildren<Image>(true).FirstOrDefault(i => i.gameObject.name == forced);
            if (icon == null) icon = PickIcon(item, labelTexts);
            if (icon != null)
            {
                icon.sprite = GetIcon();
                icon.type = Image.Type.Simple;
                icon.color = Color.white;
                icon.preserveAspect = true;
            }
            else
            {
                AddBadge(go.transform);
            }

            // Hover text: while the pointer is over the button, rewrite the game's hover label (wherever it lives).
            var relay = go.GetComponent<HoverRelay>();
            if (relay == null) relay = go.AddComponent<HoverRelay>();
            relay.OriginalLabel = (ModManagerPlugin.ButtonToReplace.Value ?? "").Trim();
            relay.NewLabel = newLabel;

            _clone = go;
            if (ModManagerUI.Instance != null) ModManagerUI.Instance.SetFloatingButton(false);
            ModManagerPlugin.Log.LogInfo($"Replaced the '{oldName}' button ({PathOf(item)}) with the Mod Manager button. " +
                                         $"Label texts changed: {labelTexts.Count}. Icon: {(icon != null ? "swapped image " + PathOf(icon.transform) : "overlay badge")}." +
                                         $"\n{sb}");
            return true;
        }

        private void TryInject()
        {
            if (ModManagerPlugin.ReplaceExistingButton.Value && TryReplaceButton(FindGroups())) return;

            string target = (ModManagerPlugin.TargetParentPath.Value ?? "").Trim();
            int min = ModManagerPlugin.MinButtonsInGroup.Value;

            Group best = null;
            int bestScore = int.MinValue;

            foreach (var g in FindGroups())
            {
                if (IsOurs(g)) continue;

                int hits = 0;
                if (target.Length > 0)
                {
                    if (PathOf(g.Parent) != target) continue;
                }
                else
                {
                    hits = MenuHits(g);
                    bool looksLikeMenu = hits > 0;
                    if (!looksLikeMenu && (g.Items.Count < min || IsExcluded(g))) continue;
                }

                int score = hits * 1000 + g.Items.Count * 10 + (g.Parent.gameObject.activeInHierarchy ? 5 : 0);
                if (score > bestScore) { bestScore = score; best = g; }
            }

            if (!_loggedFirstScan)
            {
                _loggedFirstScan = true;
                if (best == null)
                    ModManagerPlugin.Log.LogInfo("No menu found yet; will keep looking. Press the dump key to list candidates.");
            }

            if (best != null) Inject(best);
        }

        private void Inject(Group group)
        {
            var parent = group.Parent;
            var ordered = group.Items.OrderBy(t => t.GetSiblingIndex()).ToList();

            // Copy a normal-looking button (not Exit), and slot the new one in just above Exit.
            var exitItem = ordered.FirstOrDefault(IsExitItem);
            var template = ordered.LastOrDefault(t => t != exitItem) ?? ordered[ordered.Count - 1];

            var go = Instantiate(template.gameObject, parent);
            go.name = CloneName;
            go.SetActive(true);
            if (exitItem != null) go.transform.SetSiblingIndex(exitItem.GetSiblingIndex());
            else go.transform.SetAsLastSibling();

            // Stop the game's own localisation from overwriting our label.
            foreach (var mb in go.GetComponentsInChildren<MonoBehaviour>(true))
                if (mb != null && LocalizationComponents.Contains(mb.GetType().Name))
                    DestroyImmediate(mb);

            string label = ModManagerPlugin.ButtonLabel.Value;
            TMP_FontAsset font = null;
            foreach (var t in go.GetComponentsInChildren<TMP_Text>(true))
            {
                t.text = label;
                if (font == null) font = t.font;
            }
            foreach (var t in go.GetComponentsInChildren<Text>(true)) t.text = label;
            if (font != null && ModManagerUI.Instance != null) ModManagerUI.Instance.Font = font;

            // Remove everything the copied button used to do, then wire it to us.
            foreach (var b in go.GetComponentsInChildren<Button>(true))
            {
                DisablePersistent(b.onClick);
                b.onClick.AddListener(OpenManager);
            }
            if (_customButtonType != null)
            {
                var field = _customButtonType.GetField("onClickedEvent");
                foreach (var comp in go.GetComponentsInChildren(_customButtonType, true))
                {
                    var ev = field != null ? field.GetValue(comp) as UnityEventBase : null;
                    if (ev == null) continue;
                    DisablePersistent(ev);
                    var plain = ev as UnityEvent;
                    if (plain != null) plain.AddListener(OpenManager);
                }
            }

            // Menus without a layout group need the new button placed by hand.
            if (parent.GetComponent<LayoutGroup>() == null && ordered.Count >= 2)
            {
                var a = ordered[ordered.Count - 2] as RectTransform;
                var b = ordered[ordered.Count - 1] as RectTransform;
                var c = go.transform as RectTransform;
                if (a != null && b != null && c != null)
                    c.anchoredPosition = b.anchoredPosition + (b.anchoredPosition - a.anchoredPosition);
            }

            var parentRect = parent as RectTransform;
            if (parentRect != null) LayoutRebuilder.ForceRebuildLayoutImmediate(parentRect);

            _clone = go;
            if (ModManagerUI.Instance != null) ModManagerUI.Instance.SetFloatingButton(false);
            ModManagerPlugin.Log.LogInfo($"Added '{label}' button to menu: {PathOf(parent)} ({group.Items.Count} existing buttons).");
        }

        private static void DisablePersistent(UnityEventBase ev)
        {
            for (int i = ev.GetPersistentEventCount() - 1; i >= 0; i--)
                ev.SetPersistentListenerState(i, UnityEventCallState.Off);
        }

        // The cloned button may fire through both its Button and the game's CustomButton event,
        // so opening has to be idempotent (Show() ignores repeat calls while open).
        private static void OpenManager()
        {
            if (ModManagerUI.Instance != null) ModManagerUI.Instance.Show();
        }
    }

    /// <summary>
    /// Safety net for the hover label: while the pointer is over the replaced button, any label inside it that
    /// still shows the old text ("Tips") is rewritten to ours, and put back afterwards.
    /// </summary>
    internal sealed class HoverRelay : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        public string OriginalLabel = "";
        public string NewLabel = "MODS";

        private readonly Dictionary<TMP_Text, string> _changed = new Dictionary<TMP_Text, string>();
        private bool _hover;
        private float _next;

        public void OnPointerEnter(PointerEventData eventData)
        {
            _hover = true;
            _next = 0f;
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            _hover = false;
            Restore();
        }

        private void OnDisable()
        {
            _hover = false;
            Restore();
        }

        private void Update()
        {
            if (!_hover || OriginalLabel.Length == 0 || Time.unscaledTime < _next) return;
            _next = Time.unscaledTime + 0.08f;

            foreach (var t in GetComponentsInChildren<TMP_Text>(true))
            {
                string shown = Regex.Replace(t.text ?? "", "<.*?>", "").Trim();
                if (!string.Equals(shown, OriginalLabel, StringComparison.OrdinalIgnoreCase)) continue;
                if (!_changed.ContainsKey(t)) _changed[t] = t.text;
                t.text = NewLabel;
            }
        }

        private void Restore()
        {
            foreach (var kv in _changed)
                if (kv.Key != null) kv.Key.text = kv.Value;
            _changed.Clear();
        }
    }
}
