using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace ModManager
{
    internal sealed class ModEntry
    {
        public string Name;
        public string Version = "";
        public string Guid = "";
        public string Path;
        public bool Loaded;
        public bool Disabled;
        public ConfigFile Config;
    }

    /// <summary>The mod manager window: mod list on the left, config editor on the right.</summary>
    internal sealed class ModManagerUI : MonoBehaviour
    {
        public static ModManagerUI Instance;

        public TMP_FontAsset Font;

        // palette
        private static readonly Color Dim = new Color(0f, 0f, 0f, 0.70f);
        private static readonly Color WindowBg = new Color(0.075f, 0.085f, 0.10f, 1f);
        private static readonly Color PanelBg = new Color(0.105f, 0.12f, 0.14f, 1f);
        private static readonly Color RowBg = new Color(0.145f, 0.165f, 0.19f, 1f);
        private static readonly Color RowSelected = new Color(0.12f, 0.36f, 0.34f, 1f);
        private static readonly Color Accent = new Color(0.16f, 0.62f, 0.56f, 1f);
        private static readonly Color Neutral = new Color(0.24f, 0.27f, 0.31f, 1f);
        private static readonly Color Danger = new Color(0.62f, 0.22f, 0.22f, 1f);
        private static readonly Color FieldBg = new Color(0.05f, 0.06f, 0.075f, 1f);
        private static readonly Color TextMain = new Color(0.92f, 0.94f, 0.96f, 1f);
        private static readonly Color TextMuted = new Color(0.58f, 0.63f, 0.70f, 1f);
        private static readonly Color TextDim = new Color(0.42f, 0.47f, 0.53f, 1f);

        private GameObject _canvasGo;
        private GameObject _root;
        private GameObject _floating;
        private RectTransform _listContent;
        private RectTransform _entryContent;
        private RectTransform _toolbar;
        private TMP_Text _title;
        private TMP_Text _meta;
        private TMP_Text _status;
        private TMP_Text _unloadedToggleLabel;

        private readonly List<ModEntry> _mods = new List<ModEntry>();
        private readonly List<Behaviour> _pausedInput = new List<Behaviour>();
        private ModEntry _selected;
        private bool _showUnloaded;
        private bool _built;
        private bool _open;

        public bool IsOpen { get { return _open; } }

        private void Awake()
        {
            Instance = this;
        }

        private void Update()
        {
            if (!_open) return;
            try { if (Input.GetKeyDown(KeyCode.Escape)) Hide(); }
            catch (InvalidOperationException) { /* legacy input disabled: use the X button */ }
        }

        private void OnDestroy()
        {
            if (_open) PauseGameInput(false);
            if (_canvasGo != null) Destroy(_canvasGo);
            if (Instance == this) Instance = null;
        }

        // ------------------------------------------------------------------ open / close

        public void Toggle()
        {
            if (_open) Hide(); else Show();
        }

        public void Show()
        {
            if (_open) return;
            if (ModManagerPlugin.OpenInSeparateWindow.Value && ExternalWindow.TryOpen()) return;
            EnsureBuilt();
            _open = true;
            Rescan();
            BuildList();
            BuildDetail();
            _root.SetActive(true);
            PauseGameInput(true);
        }

        public void Hide()
        {
            if (!_open) return;
            _open = false;
            if (_root != null) _root.SetActive(false);
            PauseGameInput(false);
        }

        public void SetFloatingButton(bool visible)
        {
            if (visible)
            {
                EnsureBuilt();
                _floating.SetActive(true);
            }
            else if (_floating != null)
            {
                _floating.SetActive(false);
            }
        }

        // Typing in a text field must not trigger the game's trade hotkeys.
        private void PauseGameInput(bool pause)
        {
            if (pause)
            {
                _pausedInput.Clear();
                var t = Type.GetType("HotkeyInput, Assembly-CSharp");
                if (t == null) return;
                foreach (var o in Resources.FindObjectsOfTypeAll(t))
                {
                    var b = o as Behaviour;
                    if (b != null && b.enabled && b.gameObject.scene.IsValid())
                    {
                        b.enabled = false;
                        _pausedInput.Add(b);
                    }
                }
            }
            else
            {
                foreach (var b in _pausedInput)
                    if (b != null) b.enabled = true;
                _pausedInput.Clear();
            }
        }

        // ------------------------------------------------------------------ mod discovery

        private void Rescan()
        {
            string keepKey = _selected != null ? (_selected.Guid + "|" + _selected.Path) : null;
            _mods.Clear();
            var loadedPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var kv in Chainloader.PluginInfos)
            {
                var pi = kv.Value;
                string path = pi.Location ?? "";
                _mods.Add(new ModEntry
                {
                    Name = pi.Metadata.Name,
                    Version = pi.Metadata.Version.ToString(),
                    Guid = pi.Metadata.GUID,
                    Path = path,
                    Loaded = true,
                    Disabled = false,
                    Config = pi.Instance != null ? pi.Instance.Config : null
                });
                try { if (path.Length > 0) loadedPaths.Add(System.IO.Path.GetFullPath(path)); } catch { }
            }
            _mods.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));

            if (_showUnloaded)
            {
                try
                {
                    var extra = new List<ModEntry>();
                    foreach (var f in Directory.GetFiles(Paths.PluginPath, "*.dll*", SearchOption.AllDirectories))
                    {
                        bool disabled = f.EndsWith(".dll.disabled", StringComparison.OrdinalIgnoreCase);
                        if (!disabled && !f.EndsWith(".dll", StringComparison.OrdinalIgnoreCase)) continue;
                        if (loadedPaths.Contains(System.IO.Path.GetFullPath(f))) continue;
                        extra.Add(new ModEntry
                        {
                            Name = System.IO.Path.GetFileName(f),
                            Path = f,
                            Loaded = false,
                            Disabled = disabled
                        });
                    }
                    extra.Sort((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
                    _mods.AddRange(extra);
                }
                catch (Exception e)
                {
                    ModManagerPlugin.Log.LogWarning("Could not scan plugins folder: " + e.Message);
                }
            }

            _selected = keepKey == null ? null : _mods.FirstOrDefault(m => (m.Guid + "|" + m.Path) == keepKey);
            if (_selected == null) _selected = _mods.FirstOrDefault();
        }

        // ------------------------------------------------------------------ list (left)

        private void BuildList()
        {
            ClearChildren(_listContent);

            AddText(_listContent, $"Installed mods ({_mods.Count(m => m.Loaded)} loaded)", 16, TextMuted);

            foreach (var mod in _mods)
            {
                var m = mod;
                bool sel = _selected == m;
                var b = AddButton(_listContent, "", () => { _selected = m; BuildList(); BuildDetail(); },
                    sel ? RowSelected : RowBg, 0, 58, 18, TextAnchor.MiddleLeft);
                var label = b.GetComponentInChildren<TMP_Text>();
                label.alignment = TextAlignmentOptions.MidlineLeft;
                label.rectTransform.offsetMin = new Vector2(12, 2);
                string sub;
                if (!m.Loaded) sub = m.Disabled ? "disabled" : "not loaded as a plugin";
                else
                {
                    int n = m.Config != null ? m.Config.Keys.Count : 0;
                    sub = "v" + m.Version + "  -  " + n + (n == 1 ? " setting" : " settings");
                    if (m.Disabled) sub += "  -  disabled after restart";
                }
                label.text = m.Name + "\n<size=75%><color=#8a94a3>" + sub + "</color></size>";
            }

            var toggle = AddButton(_listContent, "", () =>
            {
                _showUnloaded = !_showUnloaded;
                Rescan(); BuildList(); BuildDetail();
            }, Neutral, 0, 36, 15);
            _unloadedToggleLabel = toggle.GetComponentInChildren<TMP_Text>();
            _unloadedToggleLabel.text = _showUnloaded ? "Hide other DLLs in plugins folder" : "Show other DLLs in plugins folder";

            RebuildLayout(_listContent);
        }

        // ------------------------------------------------------------------ detail (right)

        private void BuildDetail()
        {
            ClearChildren(_toolbar);
            ClearChildren(_entryContent);

            var m = _selected;
            if (m == null)
            {
                _title.text = "No mods found";
                _meta.text = "Drop plugin DLLs into BepInEx/plugins and restart the game.";
                return;
            }

            _title.text = m.Loaded
                ? m.Name + "  <size=60%><color=#8a94a3>v" + m.Version + "</color></size>"
                : m.Name;
            _meta.text = m.Loaded
                ? "GUID: " + m.Guid + "\nFile: " + m.Path
                : "File: " + m.Path + "\n" + (m.Disabled
                    ? "Disabled (renamed to .disabled). Enable it and restart to load."
                    : "Not loaded as a BepInEx plugin (this may simply be a library another mod uses).");

            bool isSelf = m.Guid == ModManagerPlugin.PluginGuid;

            if (m.Loaded && m.Config != null)
            {
                AddButton(_toolbar, "Reload from disk", () =>
                {
                    try { m.Config.Reload(); SetStatus("Reloaded " + m.Name + " config from disk.", false); }
                    catch (Exception e) { SetStatus("Reload failed: " + e.Message, true); }
                    BuildDetail();
                }, Neutral, 170, 38, 16);

                AddButton(_toolbar, "Reset all to defaults", () =>
                {
                    int n = 0;
                    foreach (var def in m.Config.Keys.ToList())
                    {
                        try { var e = m.Config[def]; e.BoxedValue = e.DefaultValue; n++; } catch { }
                    }
                    try { m.Config.Save(); } catch { }
                    SetStatus("Reset " + n + " settings of " + m.Name + " to defaults.", false);
                    BuildDetail();
                }, Danger, 190, 38, 16);
            }

            if (!isSelf && !string.IsNullOrEmpty(m.Path))
            {
                AddButton(_toolbar, m.Disabled ? "Enable (needs restart)" : "Disable (needs restart)",
                    () => ToggleDisabled(m), Neutral, 210, 38, 16);
            }

            if (!m.Loaded || m.Config == null)
            {
                AddText(_entryContent, "Nothing to configure here.", 18, TextMuted);
                RebuildLayout(_entryContent);
                return;
            }

            BuildConfigRows(m.Config);
            RebuildLayout(_entryContent);
        }

        private void ToggleDisabled(ModEntry m)
        {
            try
            {
                string p = m.Path;
                string np;
                if (m.Disabled) np = p.EndsWith(".disabled", StringComparison.OrdinalIgnoreCase) ? p.Substring(0, p.Length - ".disabled".Length) : p;
                else np = p + ".disabled";
                File.Move(p, np);
                m.Path = np;
                m.Disabled = !m.Disabled;
                SetStatus(m.Name + (m.Disabled ? " will be disabled" : " will be enabled") + " next time the game starts.", false);
                BuildList();
                BuildDetail();
            }
            catch (Exception e)
            {
                SetStatus("Could not rename file: " + e.Message, true);
            }
        }

        private void BuildConfigRows(ConfigFile cfg)
        {
            var bySection = new Dictionary<string, List<ConfigEntryBase>>();
            var order = new List<string>();
            foreach (var def in cfg.Keys.ToList())
            {
                ConfigEntryBase e;
                try { e = cfg[def]; } catch { continue; }
                if (!TagBool(e, "Browsable", true)) continue;
                List<ConfigEntryBase> list;
                if (!bySection.TryGetValue(def.Section, out list))
                {
                    bySection[def.Section] = list = new List<ConfigEntryBase>();
                    order.Add(def.Section);
                }
                list.Add(e);
            }

            if (order.Count == 0)
            {
                AddText(_entryContent, "This mod has no configurable settings.", 18, TextMuted);
                return;
            }

            foreach (var section in order)
            {
                var head = AddText(_entryContent, section, 20, Accent, TextAlignmentOptions.Left, FontStyles.Bold);
                head.gameObject.AddComponent<LayoutElement>().minHeight = 34;
                foreach (var e in bySection[section]) BuildEntryRow(e);
            }
        }

        private void BuildEntryRow(ConfigEntryBase e)
        {
            bool readOnly = TagBool(e, "ReadOnly", false);

            var row = NewRect("Row", _entryContent);
            AddImage(row, RowBg);
            var h = row.gameObject.AddComponent<HorizontalLayoutGroup>();
            h.padding = new RectOffset(12, 12, 8, 8);
            h.spacing = 12;
            h.childAlignment = TextAnchor.MiddleLeft;
            h.childControlWidth = true;
            h.childControlHeight = true;
            h.childForceExpandWidth = false;
            h.childForceExpandHeight = false;

            var left = NewRect("Info", row);
            var v = left.gameObject.AddComponent<VerticalLayoutGroup>();
            v.childControlWidth = true;
            v.childControlHeight = true;
            v.childForceExpandWidth = true;
            v.childForceExpandHeight = false;
            var lle = left.gameObject.AddComponent<LayoutElement>();
            lle.flexibleWidth = 1;
            lle.minWidth = 120;

            AddText(left, e.Definition.Key, 19, TextMain, TextAlignmentOptions.Left, FontStyles.Bold);
            string desc = e.Description != null ? e.Description.Description : null;
            if (!string.IsNullOrEmpty(desc)) AddText(left, desc, 14, TextMuted);

            string meta = "Default: " + SafeSerialize(e, true);
            try
            {
                if (e.Description != null && e.Description.AcceptableValues != null)
                    meta += "   -   " + e.Description.AcceptableValues.ToDescriptionString().Replace("# ", "").Replace("\n", " ");
            }
            catch { }
            AddText(left, meta, 13, TextDim);

            var right = NewRect("Controls", row);
            var rh = right.gameObject.AddComponent<HorizontalLayoutGroup>();
            rh.spacing = 6;
            rh.childAlignment = TextAnchor.MiddleRight;
            rh.childControlWidth = true;
            rh.childControlHeight = true;
            rh.childForceExpandWidth = false;
            rh.childForceExpandHeight = false;
            var rle = right.gameObject.AddComponent<LayoutElement>();
            rle.preferredWidth = 400;
            rle.minWidth = 400;

            Action refresh = BuildControl(right, e, readOnly);

            if (!readOnly)
            {
                AddButton(right, "Reset", () =>
                {
                    try
                    {
                        e.BoxedValue = e.DefaultValue;
                        e.ConfigFile.Save();
                        SetStatus(e.Definition.Key + " reset to default.", false);
                    }
                    catch (Exception ex) { SetStatus("Could not reset: " + ex.Message, true); }
                    refresh();
                }, Neutral, 64, 36, 14);
            }
        }

        /// <summary>Creates the right control for the setting's type and returns a refresh callback.</summary>
        private Action BuildControl(Transform parent, ConfigEntryBase e, bool readOnly)
        {
            Type type = e.SettingType;

            // --- bool: ON/OFF toggle
            if (type == typeof(bool))
            {
                Button btn = null;
                Action refresh = () =>
                {
                    bool on = (bool)e.BoxedValue;
                    btn.GetComponentInChildren<TMP_Text>().text = on ? "ON" : "OFF";
                    btn.GetComponent<Image>().color = on ? Accent : Neutral;
                };
                btn = AddButton(parent, "", () =>
                {
                    if (readOnly) return;
                    Apply(e, !(bool)e.BoxedValue);
                    refresh();
                }, Neutral, 110, 36, 17);
                btn.interactable = !readOnly;
                refresh();
                return refresh;
            }

            // --- small enum / AcceptableValueList: < value >
            object[] options = GetOptions(e);
            if (options != null && options.Length > 0)
            {
                TMP_Text label = null;
                Action refresh = () => { label.text = Display(e.BoxedValue); };
                Action<int> step = delta =>
                {
                    if (readOnly) return;
                    int i = Array.FindIndex(options, o => object.Equals(o, e.BoxedValue));
                    i = ((i + delta) % options.Length + options.Length) % options.Length;
                    Apply(e, options[i]);
                    refresh();
                };
                var prev = AddButton(parent, "<", () => step(-1), Neutral, 40, 36, 18);
                label = AddText(parent, "", 17, TextMain, TextAlignmentOptions.Center);
                var le = label.gameObject.AddComponent<LayoutElement>();
                le.preferredWidth = 190;
                le.minWidth = 120;
                le.minHeight = 36;
                var next = AddButton(parent, ">", () => step(1), Neutral, 40, 36, 18);
                prev.interactable = next.interactable = !readOnly;
                refresh();
                return refresh;
            }

            // --- everything else: text field using BepInEx's own (de)serialiser
            TMP_InputField input = null;
            Action refreshText = () => { input.SetTextWithoutNotify(SafeSerialize(e, false)); };
            input = AddInput(parent, SafeSerialize(e, false), 280, text =>
            {
                if (readOnly) { refreshText(); return; }
                try
                {
                    e.SetSerializedValue(text);
                    e.ConfigFile.Save();
                    SetStatus(e.Definition.Key + " set to " + SafeSerialize(e, false), false);
                }
                catch (Exception ex)
                {
                    SetStatus("Invalid value for " + e.Definition.Key + ": " + ex.Message, true);
                }
                refreshText();
            });
            input.interactable = !readOnly;
            return refreshText;
        }

        private void Apply(ConfigEntryBase e, object value)
        {
            try
            {
                e.BoxedValue = value;
                e.ConfigFile.Save();
                SetStatus(e.Definition.Key + " = " + Display(e.BoxedValue), false);
            }
            catch (Exception ex)
            {
                SetStatus("Could not change " + e.Definition.Key + ": " + ex.Message, true);
            }
        }

        // ------------------------------------------------------------------ config helpers

        private static object[] GetOptions(ConfigEntryBase e)
        {
            Type t = e.SettingType;
            if (t.IsEnum)
            {
                var vals = Enum.GetValues(t).Cast<object>().ToArray();
                return vals.Length <= 24 ? vals : null; // KeyCode & friends are typed in instead
            }
            var av = e.Description != null ? e.Description.AcceptableValues : null;
            if (av != null)
            {
                var p = av.GetType().GetProperty("AcceptableValues");
                var arr = p != null ? p.GetValue(av, null) as Array : null;
                if (arr != null) return arr.Cast<object>().ToArray();
            }
            return null;
        }

        private static string Display(object v)
        {
            return v == null ? "" : v.ToString();
        }

        private static string SafeSerialize(ConfigEntryBase e, bool useDefault)
        {
            try
            {
                object v = useDefault ? e.DefaultValue : e.BoxedValue;
                return TomlTypeConverter.ConvertToString(v, e.SettingType);
            }
            catch
            {
                return Display(useDefault ? e.DefaultValue : e.BoxedValue);
            }
        }

        // Reads a bool from a tag object (e.g. ConfigurationManagerAttributes.Browsable / ReadOnly) by reflection.
        private static bool TagBool(ConfigEntryBase e, string name, bool fallback)
        {
            var tags = e.Description != null ? e.Description.Tags : null;
            if (tags == null) return fallback;
            foreach (var tag in tags)
            {
                if (tag == null) continue;
                var ty = tag.GetType();
                object val = null;
                var f = ty.GetField(name);
                if (f != null) val = f.GetValue(tag);
                else
                {
                    var p = ty.GetProperty(name);
                    if (p != null) val = p.GetValue(tag, null);
                }
                if (val is bool) return (bool)val;
            }
            return fallback;
        }

        // ------------------------------------------------------------------ status line

        private void SetStatus(string message, bool error)
        {
            if (_status == null) return;
            _status.text = message;
            _status.color = error ? new Color(1f, 0.55f, 0.5f, 1f) : TextMuted;
        }

        // ------------------------------------------------------------------ window construction

        private void EnsureBuilt()
        {
            if (_built) return;
            _built = true;

            if (Font == null) Font = ResolveFont();
            if (EventSystem.current == null)
                new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

            _canvasGo = new GameObject("ModManagerCanvas");
            _canvasGo.layer = 5;
            DontDestroyOnLoad(_canvasGo);
            var canvas = _canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 32000;
            var scaler = _canvasGo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1280, 720);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            _canvasGo.AddComponent<GraphicRaycaster>();

            BuildFloatingButton();

            // dimmed full-screen backdrop (also swallows clicks meant for the game)
            var rootRt = NewRect("Root", _canvasGo.transform);
            Stretch(rootRt);
            AddImage(rootRt, Dim);
            _root = rootRt.gameObject;

            var window = NewRect("Window", rootRt);
            window.anchorMin = window.anchorMax = new Vector2(0.5f, 0.5f);
            window.pivot = new Vector2(0.5f, 0.5f);
            window.sizeDelta = new Vector2(1120, 640);
            AddImage(window, WindowBg);

            // title bar
            var bar = NewRect("TitleBar", window);
            bar.anchorMin = new Vector2(0, 1);
            bar.anchorMax = new Vector2(1, 1);
            bar.pivot = new Vector2(0.5f, 1);
            bar.sizeDelta = new Vector2(0, 56);
            AddImage(bar, PanelBg);
            var barLayout = bar.gameObject.AddComponent<HorizontalLayoutGroup>();
            barLayout.padding = new RectOffset(18, 12, 8, 8);
            barLayout.spacing = 10;
            barLayout.childAlignment = TextAnchor.MiddleLeft;
            barLayout.childControlWidth = true;
            barLayout.childControlHeight = true;
            barLayout.childForceExpandWidth = false;
            barLayout.childForceExpandHeight = false;
            var barTitle = AddText(bar, "Mod Manager", 26, TextMain, TextAlignmentOptions.Left, FontStyles.Bold);
            barTitle.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1;
            var hint = AddText(bar, "BepInEx " + typeof(BepInPlugin).Assembly.GetName().Version + "   |   Esc or " +
                                    ModManagerPlugin.ToggleKey.Value + " to close", 14, TextDim, TextAlignmentOptions.Right);
            hint.gameObject.AddComponent<LayoutElement>().preferredWidth = 380;
            AddButton(bar, "X", Hide, Danger, 44, 38, 20);

            // status line
            var statusRt = NewRect("StatusBar", window);
            statusRt.anchorMin = new Vector2(0, 0);
            statusRt.anchorMax = new Vector2(1, 0);
            statusRt.pivot = new Vector2(0.5f, 0);
            statusRt.sizeDelta = new Vector2(0, 34);
            AddImage(statusRt, PanelBg);
            _status = AddText(statusRt, "Changes are saved to the .cfg file immediately. Mods that read their config live will pick them up at once; others need a restart.",
                14, TextMuted, TextAlignmentOptions.MidlineLeft);
            Stretch(_status.rectTransform, 16, 0, 16, 0);

            // body
            var body = NewRect("Body", window);
            Stretch(body, 0, 34, 0, 56);
            var bodyLayout = body.gameObject.AddComponent<HorizontalLayoutGroup>();
            bodyLayout.padding = new RectOffset(10, 10, 10, 10);
            bodyLayout.spacing = 10;
            bodyLayout.childControlWidth = true;
            bodyLayout.childControlHeight = true;
            bodyLayout.childForceExpandWidth = false;
            bodyLayout.childForceExpandHeight = true;

            // left: list
            ScrollRect listScroll;
            var listRoot = AddScroll(body, "ModList", PanelBg, out listScroll, out _listContent);
            var listLe = listRoot.gameObject.AddComponent<LayoutElement>();
            listLe.preferredWidth = 330;
            listLe.minWidth = 330;

            // right: details
            var right = NewRect("Details", body);
            var rightLe = right.gameObject.AddComponent<LayoutElement>();
            rightLe.flexibleWidth = 1;
            var rv = right.gameObject.AddComponent<VerticalLayoutGroup>();
            rv.spacing = 8;
            rv.childControlWidth = true;
            rv.childControlHeight = true;
            rv.childForceExpandWidth = true;
            rv.childForceExpandHeight = false;

            _title = AddText(right, "", 28, TextMain, TextAlignmentOptions.Left, FontStyles.Bold);
            _meta = AddText(right, "", 13, TextDim, TextAlignmentOptions.Left);

            _toolbar = NewRect("Toolbar", right);
            var tl = _toolbar.gameObject.AddComponent<HorizontalLayoutGroup>();
            tl.spacing = 8;
            tl.childAlignment = TextAnchor.MiddleLeft;
            tl.childControlWidth = true;
            tl.childControlHeight = true;
            tl.childForceExpandWidth = false;
            tl.childForceExpandHeight = false;
            _toolbar.gameObject.AddComponent<LayoutElement>().minHeight = 40;

            ScrollRect entryScroll;
            var entryRoot = AddScroll(right, "Entries", PanelBg, out entryScroll, out _entryContent);
            var entryLe = entryRoot.gameObject.AddComponent<LayoutElement>();
            entryLe.flexibleHeight = 1;
            entryLe.minHeight = 120;

            _root.SetActive(false);
        }

        private void BuildFloatingButton()
        {
            var rt = NewRect("FloatingModsButton", _canvasGo.transform);
            rt.anchorMin = rt.anchorMax = new Vector2(1, 1);
            rt.pivot = new Vector2(1, 1);
            rt.anchoredPosition = new Vector2(-12, -12);
            rt.sizeDelta = new Vector2(96, 34);
            var img = AddImage(rt, Accent);
            var b = rt.gameObject.AddComponent<Button>();
            b.targetGraphic = img;
            b.onClick.AddListener(Show);
            var label = AddText(rt, ModManagerPlugin.ButtonLabel.Value, 17, TextMain, TextAlignmentOptions.Center, FontStyles.Bold);
            Stretch(label.rectTransform);
            _floating = rt.gameObject;
            _floating.SetActive(false);
        }

        private TMP_FontAsset ResolveFont()
        {
            try
            {
                var fa = TMP_Settings.defaultFontAsset;
                if (fa != null) return fa;
            }
            catch { }
            foreach (var t in Resources.FindObjectsOfTypeAll<TMP_Text>())
                if (t != null && t.font != null) return t.font;
            return null;
        }

        // ------------------------------------------------------------------ tiny UI toolkit

        private static RectTransform NewRect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = parent.gameObject.layer;
            var rt = (RectTransform)go.transform;
            rt.SetParent(parent, false);
            return rt;
        }

        private static void Stretch(RectTransform rt, float left = 0, float bottom = 0, float right = 0, float top = 0)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = new Vector2(left, bottom);
            rt.offsetMax = new Vector2(-right, -top);
        }

        private static Image AddImage(RectTransform rt, Color color)
        {
            var img = rt.gameObject.AddComponent<Image>();
            img.color = color;
            return img;
        }

        private TMP_Text AddText(Transform parent, string text, float size, Color color,
            TextAlignmentOptions align = TextAlignmentOptions.Left, FontStyles style = FontStyles.Normal)
        {
            var rt = NewRect("Text", parent);
            var t = rt.gameObject.AddComponent<TextMeshProUGUI>();
            if (Font != null) t.font = Font;
            t.text = text;
            t.fontSize = size;
            t.color = color;
            t.alignment = align;
            t.fontStyle = style;
            t.raycastTarget = false;
            return t;
        }

        private Button AddButton(Transform parent, string label, Action onClick, Color bg,
            float width, float height, float fontSize, TextAnchor ignored = TextAnchor.MiddleCenter)
        {
            var rt = NewRect("Button", parent);
            var img = AddImage(rt, bg);
            var b = rt.gameObject.AddComponent<Button>();
            b.targetGraphic = img;
            var colors = b.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(0.82f, 0.82f, 0.82f, 1f);
            colors.pressedColor = new Color(0.62f, 0.62f, 0.62f, 1f);
            colors.selectedColor = Color.white;
            colors.disabledColor = new Color(0.5f, 0.5f, 0.5f, 0.7f);
            b.colors = colors;
            var nav = b.navigation;
            nav.mode = Navigation.Mode.None;
            b.navigation = nav;
            if (onClick != null) b.onClick.AddListener(() => onClick());

            var le = rt.gameObject.AddComponent<LayoutElement>();
            if (width > 0) { le.preferredWidth = width; le.minWidth = width; }
            le.preferredHeight = height;
            le.minHeight = height;

            var t = AddText(rt, label, fontSize, TextMain, TextAlignmentOptions.Center);
            Stretch(t.rectTransform, 6, 2, 6, 2);
            return b;
        }

        private TMP_InputField AddInput(Transform parent, string value, float width, Action<string> onEndEdit)
        {
            var rt = NewRect("Input", parent);
            var img = AddImage(rt, FieldBg);
            var le = rt.gameObject.AddComponent<LayoutElement>();
            le.preferredWidth = width;
            le.minWidth = width;
            le.preferredHeight = 36;
            le.minHeight = 36;

            var area = NewRect("TextArea", rt);
            Stretch(area, 8, 4, 8, 4);
            area.gameObject.AddComponent<RectMask2D>();
            var text = AddText(area, "", 17, TextMain, TextAlignmentOptions.MidlineLeft);
            Stretch(text.rectTransform);
            text.raycastTarget = true;

            // configure while inactive so TMP_InputField sees all references in its first OnEnable
            rt.gameObject.SetActive(false);
            var input = rt.gameObject.AddComponent<TMP_InputField>();
            input.textViewport = area;
            input.textComponent = text;
            input.targetGraphic = img;
            input.lineType = TMP_InputField.LineType.SingleLine;
            input.text = value;
            input.onEndEdit.AddListener(s => onEndEdit(s));
            rt.gameObject.SetActive(true);
            return input;
        }

        private static RectTransform AddScroll(Transform parent, string name, Color bg, out ScrollRect scroll, out RectTransform content)
        {
            var rt = NewRect(name, parent);
            AddImage(rt, bg);
            scroll = rt.gameObject.AddComponent<ScrollRect>();

            var viewport = NewRect("Viewport", rt);
            Stretch(viewport, 2, 2, 2, 2);
            viewport.gameObject.AddComponent<RectMask2D>();

            content = NewRect("Content", viewport);
            content.anchorMin = new Vector2(0, 1);
            content.anchorMax = new Vector2(1, 1);
            content.pivot = new Vector2(0.5f, 1);
            content.sizeDelta = Vector2.zero;
            var vlg = content.gameObject.AddComponent<VerticalLayoutGroup>();
            vlg.padding = new RectOffset(8, 8, 8, 8);
            vlg.spacing = 6;
            vlg.childControlWidth = true;
            vlg.childControlHeight = true;
            vlg.childForceExpandWidth = true;
            vlg.childForceExpandHeight = false;
            var fitter = content.gameObject.AddComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

            scroll.viewport = viewport;
            scroll.content = content;
            scroll.horizontal = false;
            scroll.vertical = true;
            scroll.movementType = ScrollRect.MovementType.Clamped;
            scroll.scrollSensitivity = 40f;
            return rt;
        }

        private static void ClearChildren(RectTransform rt)
        {
            for (int i = rt.childCount - 1; i >= 0; i--)
            {
                var child = rt.GetChild(i).gameObject;
                child.SetActive(false);
                Destroy(child);
            }
        }

        private static void RebuildLayout(RectTransform rt)
        {
            Canvas.ForceUpdateCanvases();
            LayoutRebuilder.ForceRebuildLayoutImmediate(rt);
        }
    }
}
