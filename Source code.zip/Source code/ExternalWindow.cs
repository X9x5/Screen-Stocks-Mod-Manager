using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using BepInEx;
using BepInEx.Bootstrap;
using UnityEngine;

namespace ModManager
{
    /// <summary>Launches the stand-alone Mod Manager window (a separate OS window) and keeps configs in sync with it.</summary>
    internal static class ExternalWindow
    {
        public const string ExeName = "ScreenStocksModManagerWindow.exe";

        private static Process _proc;

        public static bool Alive
        {
            get
            {
                try { return _proc != null && !_proc.HasExited; }
                catch { return false; }
            }
        }

        /// <summary>Returns true if the separate window is (now) open; false means the caller should use the in-game window.</summary>
        public static bool TryOpen()
        {
            try
            {
                if (Alive) return true; // already open (it is set to stay on top)

                string exe = Path.Combine(Paths.BepInExRootPath, "ModManagerWindow", ExeName);
                if (!File.Exists(exe))
                {
                    ModManagerPlugin.Log.LogWarning("Separate window requested but " + ExeName + " was not found in " +
                                                    Path.GetDirectoryName(exe) + ". Run build.bat again. Using the in-game window instead.");
                    return false;
                }

                string manifest = WriteManifest();
                var psi = new ProcessStartInfo(exe,
                    Quote(manifest) + " " + Quote(Paths.PluginPath) + " " + Quote(Paths.ConfigPath) + " " +
                    Process.GetCurrentProcess().Id)
                {
                    UseShellExecute = false,
                    WorkingDirectory = Path.GetDirectoryName(exe)
                };
                _proc = Process.Start(psi);
                ModManagerPlugin.Log.LogInfo("Opened the separate Mod Manager window.");
                return _proc != null;
            }
            catch (Exception e)
            {
                ModManagerPlugin.Log.LogWarning("Could not open the separate window (" + e.Message + "). Using the in-game window instead.");
                return false;
            }
        }

        /// <summary>Closes the separate window (called when the game quits).</summary>
        public static void Close()
        {
            try
            {
                if (!Alive) return;
                _proc.CloseMainWindow();
                if (!_proc.WaitForExit(800)) _proc.Kill();
            }
            catch { }
        }

        private static string Quote(string s)
        {
            return "\"" + s.TrimEnd('\\') + "\"";
        }

        // One line per loaded plugin: guid <tab> name <tab> version <tab> dll <tab> config path
        private static string WriteManifest()
        {
            Directory.CreateDirectory(Paths.CachePath);
            string path = Path.Combine(Paths.CachePath, "ModManager.plugins.tsv");
            var sb = new StringBuilder();
            foreach (var kv in Chainloader.PluginInfos)
            {
                var pi = kv.Value;
                string cfg = pi.Instance != null && pi.Instance.Config != null ? pi.Instance.Config.ConfigFilePath : "";
                sb.Append(Clean(pi.Metadata.GUID)).Append('\t')
                  .Append(Clean(pi.Metadata.Name)).Append('\t')
                  .Append(Clean(pi.Metadata.Version.ToString())).Append('\t')
                  .Append(Clean(pi.Location ?? "")).Append('\t')
                  .Append(Clean(cfg)).Append('\n');
            }
            File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
            return path;
        }

        private static string Clean(string s)
        {
            return (s ?? "").Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
        }
    }

    /// <summary>While the separate window is open, re-reads any plugin config file it changes so edits apply live.</summary>
    internal sealed class ConfigWatcher : MonoBehaviour
    {
        private readonly Dictionary<string, DateTime> _seen = new Dictionary<string, DateTime>();
        private float _next;

        private void Update()
        {
            if (Time.unscaledTime < _next) return;
            _next = Time.unscaledTime + 0.5f;

            if (!ExternalWindow.Alive)
            {
                if (_seen.Count > 0) _seen.Clear();
                return;
            }

            foreach (var kv in Chainloader.PluginInfos.ToList())
            {
                var inst = kv.Value.Instance;
                if (inst == null || inst.Config == null) continue;
                string path = inst.Config.ConfigFilePath;
                if (string.IsNullOrEmpty(path) || !File.Exists(path)) continue;

                DateTime now = File.GetLastWriteTimeUtc(path);
                DateTime last;
                if (!_seen.TryGetValue(path, out last)) { _seen[path] = now; continue; }
                if (now == last) continue;

                try
                {
                    inst.Config.Reload();
                    ModManagerPlugin.Log.LogInfo("Reloaded config: " + Path.GetFileName(path));
                }
                catch (Exception e)
                {
                    ModManagerPlugin.Log.LogWarning("Could not reload " + Path.GetFileName(path) + ": " + e.Message);
                }
                _seen[path] = File.GetLastWriteTimeUtc(path);
            }
        }
    }
}
