using System;
using System.IO;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using UnityEngine;

namespace ModManager
{
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public sealed class ModManagerPlugin : BaseUnityPlugin
    {
        public const string PluginGuid = "local.screenstocks.modmanager";
        public const string PluginName = "Mod Manager";
        public const string PluginVersion = "1.0.0";

        internal static ManualLogSource Log;
        internal static string PluginDir;
        internal static ConfigEntry<bool> OpenInSeparateWindow;
        internal static ConfigEntry<KeyCode> ToggleKey;
        internal static ConfigEntry<KeyCode> DumpKey;
        internal static ConfigEntry<string> ButtonLabel;
        internal static ConfigEntry<string> TargetParentPath;
        internal static ConfigEntry<int> MinButtonsInGroup;
        internal static ConfigEntry<bool> ReplaceExistingButton;
        internal static ConfigEntry<string> ButtonToReplace;
        internal static ConfigEntry<string> IconImageName;
        internal static ConfigEntry<bool> FloatingFallback;
        internal static ConfigEntry<float> FallbackDelaySeconds;

        private ModManagerUI _ui;
        private MenuInjector _injector;

        private void Awake()
        {
            Log = Logger;
            PluginDir = Path.GetDirectoryName(Info.Location) ?? Paths.PluginPath;

            OpenInSeparateWindow = Config.Bind("Window", "OpenInSeparateWindow", false,
                "false: the Mod Manager opens inside the game window. true: it opens as its own separate window " +
                "(needs BepInEx\\ModManagerWindow\\ScreenStocksModManagerWindow.exe; build.bat installs it).");
            ToggleKey = Config.Bind("General", "ToggleKey", KeyCode.F10,
                "Hotkey that opens/closes the Mod Manager from anywhere.");
            ReplaceExistingButton = Config.Bind("Menu", "ReplaceExistingButton", true,
                "Turn an existing game button into the Mod Manager button (opens this window). " +
                "If false, or if that button is not found, a separate button is added to the menu instead.");
            ButtonToReplace = Config.Bind("Menu", "ButtonToReplace", "tips",
                "Which button to take over: matched against the button's text, object name and click-handler class. " +
                "The Quit button is left alone.");
            IconImageName = Config.Bind("Menu", "IconImageName", "",
                "Advanced. Leave empty to auto-detect which image is the button's icon. If the wrong image gets the new icon, " +
                "put the exact object name of the right image here (the log lists them after 'Replaced the').");
            ButtonLabel = Config.Bind("Menu", "ButtonLabel", "MODS",
                "Text shown on the button that is added to the game's menu.");
            TargetParentPath = Config.Bind("Menu", "TargetParentPath", "",
                "Advanced. Leave empty to auto-detect the menu. If the button lands in the wrong place, press the " +
                "dump hotkey, look in BepInEx/LogOutput.log for the candidate menu paths, and paste the right one here.");
            MinButtonsInGroup = Config.Bind("Menu", "MinButtonsInGroup", 2,
                new ConfigDescription("A group of game buttons needs at least this many buttons to count as 'the menu'.",
                    new AcceptableValueRange<int>(1, 20)));
            DumpKey = Config.Bind("Menu", "DumpKey", KeyCode.F9,
                "Logs every candidate menu button group to the BepInEx log (for troubleshooting).");
            FloatingFallback = Config.Bind("Menu", "FloatingFallback", true,
                "If the in-menu button cannot be placed, show a small floating MODS button in the top-right corner instead.");
            FallbackDelaySeconds = Config.Bind("Menu", "FallbackDelaySeconds", 20f,
                new ConfigDescription("How long to keep looking for the menu before showing the floating button.",
                    new AcceptableValueRange<float>(2f, 120f)));

            _ui = gameObject.AddComponent<ModManagerUI>();
            _injector = gameObject.AddComponent<MenuInjector>();
            gameObject.AddComponent<ConfigWatcher>();
            Logger.LogInfo($"{PluginName} {PluginVersion} loaded. Press {ToggleKey.Value} to open it.");
        }

        private void OnApplicationQuit()
        {
            ExternalWindow.Close();
        }

        private void OnDestroy()
        {
            ExternalWindow.Close();
        }

        private void Update()
        {
            try
            {
                if (Input.GetKeyDown(ToggleKey.Value)) _ui.Toggle();
                if (Input.GetKeyDown(DumpKey.Value)) _injector.DumpCandidates();
            }
            catch (InvalidOperationException)
            {
                // Legacy input is disabled in this build; the in-menu button still works.
            }
        }
    }
}
